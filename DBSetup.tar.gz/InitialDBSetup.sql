﻿USE [FaxNoLogsDB];

BEGIN TRANSACTION;

IF SCHEMA_ID(N'model') IS NULL EXEC(N'CREATE SCHEMA [model];');

CREATE TABLE [model].[Companies] (
    [CompaniesId] int NOT NULL,
    [CompanyName] nvarchar(max) NULL,
    CONSTRAINT [PK_Companies] PRIMARY KEY ([CompaniesId])
);

CREATE TABLE [model].[UserLevels] (
    [UserLevelsId] int NOT NULL IDENTITY,
    [UserLevelsDescr] nvarchar(max) NULL,
    CONSTRAINT [PK_UserLevels] PRIMARY KEY ([UserLevelsId])
);

CREATE TABLE [model].[Users] (
    [UsersId] int NOT NULL IDENTITY,
    [UserName] nvarchar(max) NULL,
    [UserDescr] nvarchar(max) NULL,
    [UserLevelsId] int NULL,
    CONSTRAINT [PK_Users] PRIMARY KEY ([UsersId]),
    CONSTRAINT [FK_Users_UserLevels_UserLevelsId] FOREIGN KEY ([UserLevelsId]) REFERENCES [model].[UserLevels] ([UserLevelsId]) ON DELETE NO ACTION
);

CREATE TABLE [model].[FaxNoLogsData] (
    [FaxNoLogsDataId] int NOT NULL IDENTITY,
    [CompanyIdCompaniesId] int NULL,
    [UserIdUsersId] int NULL,
    [ImportDt] datetime2 NOT NULL,
    [LogYear] int NOT NULL,
    CONSTRAINT [PK_FaxNoLogsData] PRIMARY KEY ([FaxNoLogsDataId]),
    CONSTRAINT [FK_FaxNoLogsData_Companies_CompanyIdCompaniesId] FOREIGN KEY ([CompanyIdCompaniesId]) REFERENCES [model].[Companies] ([CompaniesId]) ON DELETE NO ACTION,
    CONSTRAINT [FK_FaxNoLogsData_Users_UserIdUsersId] FOREIGN KEY ([UserIdUsersId]) REFERENCES [model].[Users] ([UsersId]) ON DELETE NO ACTION
);

CREATE INDEX [IX_FaxNoLogsData_CompanyIdCompaniesId] ON [model].[FaxNoLogsData] ([CompanyIdCompaniesId]);

CREATE INDEX [IX_FaxNoLogsData_UserIdUsersId] ON [model].[FaxNoLogsData] ([UserIdUsersId]);

CREATE INDEX [IX_Users_UserLevelsId] ON [model].[Users] ([UserLevelsId]);

COMMIT;

BEGIN TRANSACTION;

ALTER TABLE [model].[FaxNoLogsData] ADD [Counter] int NOT NULL DEFAULT 0;

COMMIT;

BEGIN TRANSACTION;

DECLARE @var0 sysname;
SELECT @var0 = [d].[name]
FROM [sys].[default_constraints] [d]
INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
WHERE ([d].[parent_object_id] = OBJECT_ID(N'[model].[UserLevels]') AND [c].[name] = N'UserLevelsDescr');
IF @var0 IS NOT NULL EXEC(N'ALTER TABLE [model].[UserLevels] DROP CONSTRAINT [' + @var0 + '];');
ALTER TABLE [model].[UserLevels] ALTER COLUMN [UserLevelsDescr] nvarchar(450) NULL;

CREATE UNIQUE INDEX [IX_UserLevels_UserLevelsDescr] ON [model].[UserLevels] ([UserLevelsDescr]) WHERE [UserLevelsDescr] IS NOT NULL;

COMMIT;

BEGIN TRANSACTION;

ALTER TABLE [model].[Users] ADD [Password] nvarchar(max) NULL;

COMMIT;

BEGIN TRANSACTION;

ALTER TABLE [model].[Users] ADD [Created] datetime2 NOT NULL DEFAULT '0001-01-01T00:00:00.0000000';

ALTER TABLE [model].[Users] ADD [LastLogin] datetime2 NOT NULL DEFAULT '0001-01-01T00:00:00.0000000';

ALTER TABLE [model].[Users] ADD [MustResetPass] int NOT NULL DEFAULT 0;

COMMIT;

BEGIN TRANSACTION;

DECLARE @var1 sysname;
SELECT @var1 = [d].[name]
FROM [sys].[default_constraints] [d]
INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
WHERE ([d].[parent_object_id] = OBJECT_ID(N'[model].[Users]') AND [c].[name] = N'UserName');
IF @var1 IS NOT NULL EXEC(N'ALTER TABLE [model].[Users] DROP CONSTRAINT [' + @var1 + '];');
ALTER TABLE [model].[Users] ALTER COLUMN [UserName] nvarchar(450) NULL;

CREATE UNIQUE INDEX [IX_Users_UserName] ON [model].[Users] ([UserName]) WHERE [UserName] IS NOT NULL;

COMMIT;

BEGIN TRANSACTION;

Insert Into model.UserLevels (UserLevelsDescr) Values ('User');
Insert Into model.UserLevels (UserLevelsDescr) Values ('Admin');
Insert Into model.Users
(UserName,UserDescr,UserLevelsId,Password,Created,LastLogin,MustResetPass)
Values
('Admin','Administrator',2,'QnqtUM5+7n2vVm3U1cLqP1GzRTgviB4LiuWhb78YcZs=','2022-05-16 11:31:04.5021318','0001-01-01 00:00:00.0000000',0);

COMMIT;
